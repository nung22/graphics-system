/*
  Bruce Maxwell
  Fall 2014

  2D View test function
*/

int main(int argc, char *argv[]) {

  return(0);
}
