# Lab 4: Scanline Fill

**Name:** Nicholas Ung

**Using Time Travel Days:** No

**Operating System:** Mac

**IDE:** Visual Studio Code