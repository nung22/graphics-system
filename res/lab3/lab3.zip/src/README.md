# Lab 3: Graphics Primitives

**Name:** Nicholas Ung

**Using Time Travel Days:** No

**Operating System:** Mac

**IDE:** Visual Studio Code