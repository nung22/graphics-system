// These functions provide methods for reading and writing images.
// Written by Nicholas Ung 2024-05-20

#include "image.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Create an image with the specified cols and rows
Image* image_create(int rows, int cols) {
    Image* img = (Image*)malloc(sizeof(Image)); // Allocate memory for the image structure
    if (img) { // Check if the image pointer is not NULL
        img->cols = cols; // Set the image cols
        img->rows = rows; // Set the image rows
        img->data = (FPixel*)malloc(cols * rows * sizeof(FPixel)); // Allocate memory for floating-point pixel data
        img->a = (float*)malloc(cols * rows * sizeof(float)); // Allocate memory for alpha values
        img->z = (float*)malloc(cols * rows * sizeof(float)); // Allocate memory for depth values
    }
    return img; // Return the image pointer
}


// Free the memory allocated for an image
void image_free(Image* img) {
    if (img) { // Check if the image pointer is not NULL
        free(img); // Free the image structure
    }
}

// Allocate memory for an image with the specified cols and rows
void image_alloc(Image* img, int rows, int cols) {
    if (img) { // Check if the image pointer is not NULL
        img->cols = cols; // Set the image cols
        img->rows = rows; // Set the image rows
        img->data = (FPixel*)malloc(cols * rows * sizeof(FPixel)); // Allocate memory for floating-point pixel data
    }
}

// Deallocate memory for an image
void image_dealloc(Image* img) {
    if (img) { // Check if the image pointer is not NULL
        free(img->data); // Free the floating-point pixel data
        free(img->a); // Free the alpha values
        free(img->z); // Free the depth values
    }
}

// Resets every pixel to a default value (e.g. Black, alpha value of 1.0, z value of 1.0)
void image_reset(Image* img) {
    if (img) { // Check if the image pointer is not NULL
        memset(img->data, 0, img->cols * img->rows * sizeof(FPixel)); // Set all pixel values to zero
        memset(img->a, 1.0, img->cols * img->rows * sizeof(float)); // Set all alpha values to zero
        memset(img->z, 1.0, img->cols * img->rows * sizeof(float)); // Set all depth values to zero
    }
}

// Returns the FPixel at (r, c).
FPixel image_getf(Image* img, int row, int col) {
    FPixel pixel = {0}; // Initialize a pixel with all zeros
    if (img && row < img->rows && col < img->cols) { // Check if the coordinates are within bounds
        int index = row * img->cols + col; // Calculate the index of the pixel
        pixel = img->data[index]; // Get the pixel value
    }
    return pixel; // Return the pixel
}

// Returns the value of band b at pixel (r, c).
float image_getc(Image* img, int row, int col) {
    float value = 0; // Initialize the value to zero
    if (img && row < img->rows && col < img->cols) { // Check if the coordinates are within bounds
        int index = row * img->cols + col; // Calculate the index of the pixel
        value = img->data[index].rgb[0]; // Get the red channel value
    }
    return value; // Return the channel value
}

// Returns the alpha value at pixel (r, c).
float image_geta(Image* img, int row, int col) {
    float value = 0; // Initialize the value to zero
    if (img && row < img->rows && col < img->cols) { // Check if the coordinates are within bounds
        int index = row * img->cols + col; // Calculate the index of the pixel
        value = img->a[index]; // Get the alpha value
    }
    return value; // Return the alpha value
}

// Returns the depth value at pixel (r, c).
float image_getz(Image* img, int row, int col) {
    float value = 0; // Initialize the value to zero
    if (img && row < img->rows && col < img->cols) { // Check if the coordinates are within bounds
        int index = row * img->cols + col; // Calculate the index of the pixel
        value = img->z[index]; // Get the depth value
    }
    return value; // Return the depth value
}

// Sets the alpha value at pixel (r, c) to val.
void image_seta(Image* img, int row, int col, float value) {
    if (img && row < img->rows && col < img->cols) { // Check if the coordinates are within bounds
        int index = row * img->cols + col; // Calculate the index of the pixel
        img->a[index] = value; // Set the alpha value for the pixel
    }
}

// Sets the depth value at pixel (r, c) to val.
void image_setz(Image* img, int row, int col, float value) {
    if (img && row < img->rows && col < img->cols) { // Check if the coordinates are within bounds
        int index = row * img->cols + col; // Calculate the index of the pixel
        img->z[index] = value; // Set the depth value for the pixel
    }
}

// Sets the value of pixel (r, c) band b to val.
void image_setc(Image* img, int row, int col, int ch, float value) {
    if (img && row < img->rows && col < img->cols && ch >= 0 && ch < 3) { // Check if coordinates and channel are within bounds
        int index = row * img->cols + col; // Calculate the index of the pixel
        img->data[index].rgb[ch] = value; // Set the channel value for the pixel
    }
}

// Sets the values of pixel (r, c) to the FPixel val.
void image_setf(Image* img, int row, int col, FPixel value) {
    if (img && row < img->rows && col < img->cols) { // Check if the coordinates are within bounds
        int index = row * img->cols + col; // Calculate the index of the pixel
        img->data[index] = value; // Set the pixel value
    }
}

// Fills the image with the FPixel value.
void image_fill(Image* img, FPixel value) {
    if (img) { // Check if the image pointer is not NULL
        for (int i = 0; i < img->rows; i++) { // Loop over the rows
            for (int j = 0; j < img->cols; j++) { // Loop over the columns
                image_setf(img, i, j, value); // Set the pixel value
            }
        }
    }
}

// Sets the (r, g, b) values of each pixel to the given color.
void image_fillrgb(Image* img, float r, float g, float b) {
    FPixel value = {r, g, b}; // Create an FPixel with the specified color
    image_fill(img, value); // Fill the image with the color
}

// Sets the alpha value of each pixel to the given value.
void image_filla(Image* img, float a) {
    if (img) { // Check if the image pointer is not NULL
        for (int i = 0; i < img->rows; i++) { // Loop over the rows
            for (int j = 0; j < img->cols; j++) { // Loop over the columns
                image_seta(img, i, j, a); // Set the alpha value
            }
        }
    }
}

// Sets the depth value of each pixel to the given value.
void image_fillz(Image* img, float z) {
    if (img) { // Check if the image pointer is not NULL
        for (int i = 0; i < img->rows; i++) { // Loop over the rows
            for (int j = 0; j < img->cols; j++) { // Loop over the columns
                image_setz(img, i, j, z); // Set the depth value
            }
        }
    }
}

// Write the image to a file in PPM format
int image_write(Image *img, const char *filename) {
    FILE *file = fopen(filename, "w"); // Open the file for writing
    if (!file) return 0; // Return 0 if the file could not be opened
    fprintf(file, "P3\n"); // Write the PPM magic number
    fprintf(file, "%d %d\n", img->cols, img->rows); // Write the image dimensions
    fprintf(file, "255\n"); // Write the maximum pixel value
    for (int i = 0; i < img->rows; i++) { // Loop over the rows
        for (int j = 0; j < img->cols; j++) { // Loop over the columns
            FPixel pixel = img->data[i * img->cols + j]; // Get the pixel value
            fprintf(file, "%d %d %d ", (int)(pixel.rgb[0] * 255), (int)(pixel.rgb[1] * 255), (int)(pixel.rgb[2] * 255)); // Write the pixel values
        }
        fprintf(file, "\n"); // Write a newline character
    }
    fclose(file); // Close the file
    return 1; // Return 1 to indicate success
}