// These functions provide methods for reading and writing images.
// Written by Nicholas Ung 2024-05-20

#include "image.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Create an image with the specified cols and rows
Image* image_create(int rows, int cols) {
    Image* img = (Image*)malloc(sizeof(Image)); // Allocate memory for the image structure
    if (!img) return NULL; // Return NULL if memory allocation fails
    img->cols = cols; // Set the image cols
    img->rows = rows; // Set the image rows
    img->data = (Pixel*)malloc(rows * cols * sizeof(Pixel)); // Allocate memory for pixel data
    img->fdata = (FPixel*)malloc(rows * cols * sizeof(FPixel)); // Allocate memory for floating-point pixel data
    return img; // Return the created image
}

// Free the memory allocated for an image
void image_free(Image* img) {
    if (img) {
        free(img->data); // Free the pixel data
        free(img->fdata); // Free the floating-point pixel data
        free(img); // Free the image structure
    }
}

// Allocate memory for an image with the specified cols and rows
void image_alloc(Image* img, int rows, int cols) {
    img->cols = cols; // Set the image cols
    img->rows = rows; // Set the image rows
    img->data = (Pixel*)malloc(cols * rows * sizeof(Pixel)); // Allocate memory for pixel data
    img->fdata = (FPixel*)malloc(cols * rows * sizeof(FPixel)); // Allocate memory for floating-point pixel data
}

// Deallocate memory for an image
void image_dealloc(Image* img) {
    if (img) {
        free(img->data); // Free the pixel data
        free(img->fdata); // Free the floating-point pixel data
        img->data = NULL; // Set the pixel data pointer to NULL
        img->fdata = NULL; // Set the floating-point pixel data pointer to NULL
    }
}

// Reset the image to black (all zeros)
void image_reset(Image* img) {
    if (img) {
        memset(img->data, 0, img->cols * img->rows * sizeof(Pixel)); // Set all pixel data to zero
        memset(img->fdata, 0, img->cols * img->rows * sizeof(FPixel)); // Set all floating-point pixel data to zero
    }
}

// Set a channel value for a pixel
void image_setc(Image* img, int row, int col, int ch, float value) {
    if (img && row < img->rows && col < img->cols) { // Check if coordinates are within bounds
        int index = row * img->cols + col; // Calculate the index of the pixel
        if (ch == 0) img->fdata[index].rgb[0] = value; // Set the red channel value
        else if (ch == 1) img->fdata[index].rgb[1] = value; // Set the green channel value
        else if (ch == 2) img->fdata[index].rgb[2] = value; // Set the blue channel value
    }
}

// Set a floating-point pixel value
void image_setf(Image* img, int row, int col, FPixel value) {
    if (img && row < img->rows && col < img->cols) { // Check if coordinates are within bounds
        int index = row * img->cols + col; // Calculate the index of the pixel
        img->fdata[index] = value; // Set the floating-point pixel value
    }
}

// Write the image to a file in PPM format
int image_write(Image* img, const char* filename) {
    FILE* fp = fopen(filename, "wb"); // Open the file for writing in binary mode
    if (!fp) return 0; // Return 0 if the file could not be opened
    fprintf(fp, "P6\n%d %d\n255\n", img->cols, img->rows); // Write the PPM header
    for (int i = 0; i < img->cols * img->rows; i++) {
        img->data[i].rgb[0] = (unsigned char)(img->fdata[i].rgb[0] * 255); // Convert the red channel to unsigned char
        img->data[i].rgb[1] = (unsigned char)(img->fdata[i].rgb[1] * 255); // Convert the green channel to unsigned char
        img->data[i].rgb[2] = (unsigned char)(img->fdata[i].rgb[2] * 255); // Convert the blue channel to unsigned char
        fwrite(&img->data[i], sizeof(Pixel), 1, fp); // Write the pixel to the file
    }
    fclose(fp); // Close the file
    return 1; // Return 1 on success
}
