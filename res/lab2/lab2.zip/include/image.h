#ifndef IMAGE_H

#define IMAGE_H

// Structure to represent a pixel with RGB components
typedef struct {
    unsigned char rgb[3];
} Pixel;

// Structure to represent a floating-point pixel with RGB components
typedef struct {
    float rgb[3];
} FPixel;

// Structure to represent an image with its cols, rows, and pixel data
typedef struct {
    int cols;
    int rows;
    Pixel* data; // Array of pixels for the image
    FPixel* fdata; // Array of floating-point pixels for the image
} Image;

// Function prototypes for image operations
Image* image_create(int rows, int cols); // Create an image
void image_free(Image* img); // Free the memory allocated for an image
void image_alloc(Image* img, int rows, int cols); // Allocate memory for an image
void image_dealloc(Image* img); // Deallocate memory for an image
void image_reset(Image* img); // Reset the image to black
void image_setc(Image* img, int row, int col, int ch, float value); // Set a channel value for a pixel
void image_setf(Image* img, int row, int col, FPixel value); // Set a floating-point pixel value
int image_write(Image* img, const char* filename); // Write the image to a file

#endif
