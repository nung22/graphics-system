# Lab 2: Fractals

**Name:** Nicholas Ung

**Using Time Travel Days:** Yes, 2

**Operating System:** Mac

**IDE:** Visual Studio Code